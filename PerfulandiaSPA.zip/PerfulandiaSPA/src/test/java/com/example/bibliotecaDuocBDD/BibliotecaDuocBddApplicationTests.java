package com.example.bibliotecaDuocBDD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaDuocBddApplicationTests {

	@Test
	void contextLoads() {
	}

}
